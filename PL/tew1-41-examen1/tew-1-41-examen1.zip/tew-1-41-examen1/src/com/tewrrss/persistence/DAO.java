package com.tewrrss.persistence;

public interface DAO {

	boolean dropAll();

}
