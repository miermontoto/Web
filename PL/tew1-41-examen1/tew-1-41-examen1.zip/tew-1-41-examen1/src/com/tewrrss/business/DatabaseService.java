package com.tewrrss.business;

public interface DatabaseService {

	boolean reset();

}
